package com.meow.egometry;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class TheoremDetailsActivity extends AppCompatActivity {

    private TextView theoremTitleTextView;
    private ImageView theoremImageView;
    private TextView theoremProofTextView;

    private String[] theoremTitles = {"Теорема Пифагора", "Теорема Менелая", "Теорема Фаллеса"};
    private int[] theoremImages = {R.drawable.pt, R.drawable.mt, R.drawable.tt};
    private String[] theoremProofs = {
            "Пусть a, b и c - длины сторон прямоугольного треугольника, где c - гипотенуза.\n\n" +
                    "Тогда справедлива формула: a^2 + b^2 = c^2.\n\n" +
                    "Доказательство:\n" +
                    "Рассмотрим прямоугольный треугольник ABC, где AB - гипотенуза, AC и BC - катеты.\n" +
                    "По теореме Пифагора, сумма квадратов длин катетов равна квадрату длины гипотенузы, то есть AC^2 + BC^2 = AB^2.\n" +
                    "Обозначим a = AC и b = BC, тогда c = AB.\n" +
                    "Подставляя значения вместо AC, BC и AB, получим a^2 + b^2 = c^2.\n" +
                    "Таким образом, доказана формула a^2 + b^2 = c^2.",
            "В треугольнике ABC и точках D, E, F на сторонах BC, CA, AB соответственно:\n\n" +
                    "BD / DC * CE / EA * AF / FB = 1.\n\n" +
                    "Доказательство:\n" +
                    "Рассмотрим треугольник ABC и точки D, E, F, которые делят стороны BC, CA, AB соответственно.\n" +
                    "По теореме Менелая для треугольника ABC и точек D, E, F, имеем: BD / DC * CE / EA * AF / FB = 1.\n" +
                    "Таким образом, доказано равенство BD / DC * CE / EA * AF / FB = 1.",

            "В треугольнике ABC и точке M на стороне AB:\n\n" +
                    "AM / MB = AC / CB.\n\n" +
                    "Доказательство:\n" +
                    "Рассмотрим треугольник ABC и точку M на стороне AB.\n" +
                    "По теореме Понселе для треугольника ABC и точки M на стороне AB, имеем: AM / MB = AC / CB.\n" +
                    "Таким образом, доказано равенство AM / MB = AC / CB."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theorem_details);

        theoremTitleTextView = findViewById(R.id.theoremTitleTextView);
        theoremImageView = findViewById(R.id.theoremImageView);
        theoremProofTextView = findViewById(R.id.theoremProofTextView);

        int theoremPosition = getIntent().getIntExtra("theorem_position", 0);
        String theoremTitle = theoremTitles[theoremPosition];
        int theoremImage = theoremImages[theoremPosition];
        String theoremProof = theoremProofs[theoremPosition];

        theoremTitleTextView.setText(theoremTitle);
        theoremImageView.setImageResource(theoremImage);
        theoremProofTextView.setText(theoremProof);
    }
}
