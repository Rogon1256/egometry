package com.meow.egometry;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ListView theoremListView;
    private Theorem[] theorems = {
            new Theorem("Теорема Пифагора", "Класс: 10-й", "Сложность: Средняя"),
            new Theorem("Теорема Менелая", "Класс: 11-й", "Сложность: Высокая"),
            new Theorem("Теорема Фаллеса", "Класс: 9-й", "Сложность: Низкая")
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        theoremListView = findViewById(R.id.theoremListView);

        ArrayAdapter<Theorem> adapter = new ArrayAdapter<Theorem>(this, 0, theorems) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
                }

                TextView theoremTitleTextView = convertView.findViewById(android.R.id.text1);
                TextView theoremTagsTextView = convertView.findViewById(android.R.id.text2);

                Theorem theorem = getItem(position);

                theoremTitleTextView.setText(theorem.getTitle());
                theoremTagsTextView.setText(theorem.getTags());

                return convertView;
            }
        };

        theoremListView.setAdapter(adapter);

        theoremListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openTheoremDetails(position);
            }
        });
    }

    private void openTheoremDetails(int position) {
        Intent intent = new Intent(this, TheoremDetailsActivity.class);
        intent.putExtra("theorem_position", position);
        startActivity(intent);
    }
}
