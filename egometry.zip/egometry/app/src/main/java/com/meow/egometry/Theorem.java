package com.meow.egometry;

public class Theorem {
    private String title;
    private String classTag;
    private String difficultyTag;

    public Theorem(String title, String classTag, String difficultyTag) {
        this.title = title;
        this.classTag = classTag;
        this.difficultyTag = difficultyTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getClassTag() {
        return classTag;
    }

    public void setClassTag(String classTag) {
        this.classTag = classTag;
    }

    public String getDifficultyTag() {
        return difficultyTag;
    }

    public void setDifficultyTag(String difficultyTag) {
        this.difficultyTag = difficultyTag;
    }

    public String getTags() {
        return classTag + " | " + difficultyTag;
    }
}
